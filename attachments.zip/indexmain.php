<!DOCTYPE html>
<html>
<head>
    <title>Cra-wings</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=El+Messiri&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/0dbd81cc30.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
 
</head>
<body style="margin: 0px;" id="bl">
    <style >
        .menu1{
display: flex;
justify-content: space-between;

        }
        .menu2{
            display: flex;
            flex-direction: row;
        padding-top: 10px;
        }
         .searchbar{
    margin-bottom: auto;
    margin-top: auto;
    height: 60px;
    background-color: white;
    opacity: 70%;
    padding: 10px;
    }

 .searchbar:hover{
    margin-bottom: auto;
    margin-top: auto;
    height: 60px;
    background-color: white;
    opacity: 100%;
    
    padding: 10px;
    }

    .search_input{
    color: black;
    border: 0;
    outline: 0;
    background: none;
    width: 0;
    caret-color:transparent;
    line-height: 40px;
    transition: width 0.4s linear;
    padding: 0 10px;
    width: 450px;
    caret-color:red;
    transition: width 0.4s linear;
    
    }




    .search_icon{
    height: 45px;
    width: 45px;
    float: right;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    color: black;
    text-decoration:none;
}
#cut{
    font-size: 20px;cursor: pointer;
    font-weight: bold;
transform: rotate(0deg);

}

.uploadd{
background-image: url('upcoming-events-bg.jpg');
filter: contrast();
}


    </style>

     <script >   
       {
        $(document).ready(function(){
  $("#ww").click(function(){
    $("#qw").show(300);

       $("#c").css("opacity","40%");
        
  });
});

        }
          {
        $(document).ready(function(){
  $("#kri").click(function(){
    $("#qw").hide(300);

       $("#c").css("opacity","100%");
        
  });
});

        }
  {
        $(document).ready(function(){
  $("#krii").click(function(){
    $("#qww").hide(300);

       $("#c").css("opacity","100%");
        
  });
});

        }
  

          {
        $(document).ready(function(){
  $("#www").click(function(){
    $("#qww").show(300);

       $("#c").css("opacity","40%");
        
  });
});

        }

          {
        $(document).ready(function(){
  $("#ss").click(function(){
    $("#sss").css("opacity","100%");

       $("#c").css("opacity","40%");

        
  });
});

        }

  {
        $(document).ready(function(){
  $("#kris").click(function(){
    $("#sss").slideUp(1000);

       $("#c").css("opacity","100%");
        
  });
});

        }

    </script>
    <div id="e">
        <div id="c">
    <div style="background-color: white; " >
        <ul style="list-style-type: none; " class="menu1"  >

            <div class="menu2" ><li class="menu" style="padding-right: 7px; color: #B6B6B4;font-size: 23px"><i class="fa-solid fa-heart"></i></li>
            <li style="font-family: 'Nunito Sans', sans-serif; color: #4E5252; font-size: 15px; cursor: pointer;padding-right: 2px; "class="menu" id="ww" onclick="kkkk()"  >Sign-Up  |</li>  
       <li style="font-family: 'Nunito Sans', sans-serif; color: #4E5252; font-size: 15px; cursor: pointer;"class="menu" id="www" onclick="kkkk()"   >Sign-In</li>
       
       </div>
        <li> <span style="font-family: 'El Messiri', sans-serif; color: green; font-size: 35px;font-weight: bold; color: #C04000;font-weight: 1300px"class="menu" > cra-wings</span>
    </li>

<div class="menu2" > 
              <li style="font-family: 'Nunito Sans', sans-serif;padding-right: 10px;font-size: 15px ">Follow</li>

            <li class="menu" style="padding-right: 5px;color: #C04000; font-size: 23px;"><i class="fa-brands fa-facebook "></i></li>

            <li class="menu" style="padding-right: 5px;color: #C04000; font-size: 23px;"><i class="fa-brands fa-twitter"></i></li>

            <li class="menu"style="padding-right: 5px;color: #C04000; font-size: 23px;"><i class="fa-brands fa-instagram"></i></li>
     </div>
        </ul>
       </div>
<div style="background-image: url('ki.jpg'); height: 500px; ">
   
 <div class="container h-100">



    
  
    <div class="container h-100">


      <div class="d-flex justify-content-center h-100">
        <div class="searchbar">
         <form action="indexmain.php" method="POST" >
          <input class="search_input" type="text" name="ssq" placeholder="Find a Recipe">
           <input  id="ss;" type="submit" style="width: 40px;height: 40px;position: absolute;opacity: 0%;"><i class="fas fa-search" style="font-size: 25px;" ></i>
        </form>
        </div>
      </div>
    </div>
 </div>

</div >
</div><!-- <div style="width: 1000px;height: 500px;overflow: scroll;background-color: white;text-align: center;background-color: white;position: absolute;top: 100px;left: 100px; z-index: 1;
padding: 50px;  outline: black solid 1px; outline-style: double; outline-offset: -20px; " id="sss" >
   <span style="margin-left: 850px;" id="kris" ><span style="padding-top: 20px;" id="cut" >X</span></span>
  <h2>Searched Results</h2>
 -->



 <?php
 error_reporting(0);
$host="localhost";
$user="root";
$pass="";
$conn=mysqli_connect($host,$user,$pass);
$db="kk";
mysqli_select_db($conn,$db);
$search=$_POST['ssq'];
    $stmt = $conn->prepare("select * from regg where recipename= ?");
    $stmt->bind_param("s", $search);
    $stmt->execute();
    $result = $stmt->get_result();
    
if(mysqli_num_rows($result)>0)
{
while($row=mysqli_fetch_assoc($result)){ ?>






<div style="width: 1000px;height: 500px;overflow: scroll;background-color: white;text-align: center;background-color: white;position: absolute;top: 100px;left: 100px; z-index: 1;
padding: 50px;  outline: black solid 1px; outline-style: double; outline-offset: -20px; " id="sss" >
   <span style="margin-left: 850px;" id="kris" ><span style="padding-top: 20px;" id="cut" >X</span></span>
  <h2>Searched Results</h2>


    <div style="padding: 50px; display: flex;flex-wrap: wrap;">
<div style="background-image:url('<?=$row['filename']?>'); outline: 2px solid white;position: relative;
outline-offset: -50px;height: 220px; background-repeat: no-repeat;width: 400px;background-size: cover;">
 
    <p style="position: absolute; top: 70%; left: 20%; height: 25%;background-color: white ;padding:10px;text-align: center; font-size: 16px;width: 240px;font-family: 'PT Sans', sans-serif;
font-family: 'Work Sans', sans-seriftext-align: center;font-weight: bold;"><?=$row['recipename']?><span style="display: block;font-size: 12px;color:#B6B6B4 ">__________</span><span style="display: block;font-size: 12px;color: ;font-family: 'Nunito Sans', sans-serif;"></span></p>
       </div>
       <h4 style="padding-left: 20px;"><?=$row['name']?>'S Recipe </h4>
       <br>
       <span style="display: block;font-size: 12px;color:#B6B6B4 "> <br> </span><br>
 <br>      <?=$row['procedures']?>
</div>


 <?php }} ?>












</div>
<div style="text-align: center;background-color: white; width: 500px;position: absolute;top: 100px;left: 400px; z-index: 1;display: none;
padding: 50px;  outline: black solid 1px; outline-style: double; outline-offset: -20px;" id="qw" >
    
<form style="display: flex;flex-direction: column;padding-bottom: 10px;" method="post" action="mainn.php">
  <span style="margin-left: 350px;" id="kri" ><span style="padding-top: 20px;" id="cut" >X</span></span>
    
    
    <h3>Sign-Up</h3>
    <input type="email" name="em" style="padding-bottom: 10px; " placeholder="Email">
    <br>
 <input type="text" name="na" placeholder="Your Name" style="padding-bottom: 10px;"><br>
   
    <input type="text" name="cn" placeholder="Channel Name" style="padding-bottom: 10px;">
    <br>
     <input type="number" name="cd" placeholder="Contact Details" style="padding-bottom: 10px;">
   <div style="padding-bottom: 10px;"><h3 style="font-family: 'Nunito Sans', sans-serif; color: white">Procedures</h3></div>

   
    
    <input type="submit" name="" style="width: 30%" style="padding-bottom: 10px; border:3px solid green;" >

</form>
</div>
<div style="text-align: center;background-color: white; width: 500px;position: absolute;top: 100px;left: 400px; z-index: 1;display: none;
padding: 50px;  outline: black solid 1px; outline-style: double; outline-offset: -20px;" id="qww" >
    
<form style="display: flex;flex-direction: column;padding-bottom: 10px;" method="POST" action="mainnn.php">
  <span style="margin-left: 350px;" id="krii"><span style="padding-top: 20px;" id="cut" >X</span></span>
    <h3>Sign-In</h3>
    <input type="text" name="d1" style="padding-bottom: 10px; " placeholder="Channel Name">
    <br>
   
     <input type="password" name="d2" placeholder="Email" style="padding-bottom: 10px;">
   <div style="padding-bottom: 10px;"><h3 style="font-family: 'Nunito Sans', sans-serif; color: white">Procedures</h3></div>

   
    
    <input type="submit" name="" style="width: 30%" style="padding-bottom: 10px; border:3px solid green; " >

</form>
</div>



<div style="">
    <div style="padding-top:  100px;padding-left: 200PX; ">
<div style="background-image:url('corn.webp'); outline: 2px solid white;position: relative;
outline-offset: -50px;height: 320px; background-repeat: no-repeat;width: 600px;">
 
    <p style="position: absolute; top: 70%; left: 20%; height: 25%;background-color: white ;padding:10px; font-size: 16px;width: 350px;font-family: 'Nunito Sans', sans-serif;text-align: center;font-weight: bold;">11-NO FUSS RECEPIES FOR LABOUR DAY WEEKEND <span style="display: block;font-size: 12px;color:#B6B6B4 ">__________</span><span style="display: block;font-size: 12px;color: red;font-family: 'Nunito Sans', sans-serif;">BY THE EDITORS OF KT</span></p>
       </div>
</div>










</div>











<div style="display: flex;flex-direction: row;">
    <div style="padding:50px; ">
<div style="background-image:url('cook.webp'); outline: 2px solid white;position: relative;
outline-offset: -50px;height: 220px; background-repeat: no-repeat;width: 400px;">
 
    <p style="position: absolute; top: 70%; left: 20%; height: 25%;background-color: white ;padding:10px; font-size: 16px;width: 240px;font-family: 'Nunito Sans', sans-serif;text-align: center;font-weight: bold;">What to cook in September at home <span style="display: block;font-size: 12px;color:#B6B6B4 ">__________</span><span style="display: block;font-size: 12px;color: red;font-family: 'Nunito Sans', sans-serif;">BY THE EDITORS OF KT</span></p>
       </div>
</div>


    <div style="padding: 50px; ">
<div style="background-image:url('shop.webp'); outline: 2px solid white;position: relative;
outline-offset: -50px;height: 220px; background-repeat: no-repeat;width: 400px;">
 
    <p style="position: absolute; top: 70%; left: 20%; height: 25%;background-color: white ;padding:10px; font-size: 16px;width: 240px;font-family: 'Nunito Sans', sans-serif;text-align: center;font-weight: bold;">The Best Pizza oven to make Pies at home<span style="display: block;font-size: 12px;color:#B6B6B4 ">__________</span><span style="display: block;font-size: 12px;color: red;font-family: 'Nunito Sans', sans-serif;">BY THE EDITORS OF KT</span></p>
       </div>
</div>



















</div>
  <div style="color: #B6B6B4; text-align: center;">___________________________________________________________________________________________________________________________________________________________


  <div style="padding-left:  300px;padding-top: 100px;">
    
<div style="width: 800px;height: 600px; background-image: url('maindish.webp'); background-repeat: no-repeat;text-align: center;">
<div style="background-color:#C04000; right: 30% ;color: white;font-weight: bold;padding: 15px; bottom: 95%; width: 200px;">THE BIG GUIDE</div>
</div>
  </div>
</div>
<h1 style="text-align: center;font-family: 'Nunito Sans', sans-serif;position: ">SEARCH YOUR NEXT MEAL</h1>
<div style="color: #B6B6B4; text-align: center;">___________________________________________________________________________________________________________________________________________________________

</div>

</div>




 <?php
$host="localhost";
$user="root";
$pass="";
$conn=mysqli_connect($host,$user,$pass);
$db="kk";
mysqli_select_db($conn,$db);
$sql="select * from kk.regg";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
while($row=mysqli_fetch_assoc($result)){ ?>








    <div style="padding: 50px; display: flex;flex-wrap: wrap;">
<div style="background-image:url('<?=$row['filename']?>'); outline: 2px solid white;position: relative;
outline-offset: -50px;height: 220px; background-repeat: no-repeat;width: 400px;background-size: cover;">
 
    <p style="position: absolute; top: 70%; left: 20%; height: 25%;background-color: white ;padding:10px;text-align: center; font-size: 16px;width: 240px;font-family: 'PT Sans', sans-serif;
font-family: 'Work Sans', sans-seriftext-align: center;font-weight: bold;"><?=$row['recipename']?><span style="display: block;font-size: 12px;color:#B6B6B4 ">__________</span><span style="display: block;font-size: 12px;color: ;font-family: 'Nunito Sans', sans-serif;"></span></p>
       </div>
       <h4 style="padding-left: 20px;"><?=$row['name']?>'S Recipe </h4>
       <br>
       <span style="display: block;font-size: 12px;color:#B6B6B4 "> <br> </span><br>
 <br>      <?=$row['procedures']?>
</div>



        


<?php } } ?>



</body>
</html>