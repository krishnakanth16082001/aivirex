<?php

session_start();
session_destroy();
header("location:/kt/indexmain.php");
exit();



















?>